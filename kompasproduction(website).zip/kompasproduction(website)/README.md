# Kompas-Production page Design
You can open the code in ([Open my Github](https://github.com/Jasperzocratis)).

# Screenshot
Here we have layout screenshot :

![screenshot](/kompas.png)
